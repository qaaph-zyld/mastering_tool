#!/bin/bash
# ============================================================
# family_policy.sh  —  Hardcore Pop family defaults (LOCKED)
# ------------------------------------------------------------
# Source this from the master pipeline and from QC scripts:
#     . "$(dirname "$0")/family_policy.sh"
#
# Purpose: replace per-track reasoning about stereo widening
# with a single locked rule keyed off the v2 diagnostic's
# phase-correlation statistics. Encodes the family's standing
# decisions as parameters, not prose.
#
# NOTE ON SCOPE: bass-mono is staged here but DEFAULTS OFF, so
# sourcing this file changes NO existing master output. It only
# (a) formalizes the widening skip rule and (b) reserves the
# bass-mono parameters for the Stage D linear-phase build.
# Per framework rule: features are conditionally disabled,
# never deleted.
# ============================================================

# ---- House loudness targets (current single-target default) ----
TARGET_LUFS="-10.0"          # integrated, house standard (UNCHANGED default)
TARGET_TP_DBTP="-1.0"        # true peak ceiling, lossless/club path

# ---- Deliverable-specific loudness profiles (OPT-IN) ----
# Verified against 2026 platform behaviour:
#   streaming services normalize to ~-14 (Spotify/YouTube/Tidal/Amazon),
#   -16 (Apple/Deezer); loud-only services don't boost quiet tracks.
# Select a profile with: eval "$(policy_profile <name>)"
# Default behaviour (no call) keeps the -10.0 / -1.0 house standard,
# so existing sessions are byte-for-byte unaffected.
#
#   archival  : -10.0 LUFS / -1.0 dBTP   (current house standard)
#   club      :  -8.5 LUFS / -1.0 dBTP   (DJ/club, NOT normalized; PSR>=8)
#   streaming : -14.0 LUFS / -1.5 dBTP   (services stop re-limiting it;
#                                          -1.5 hedges lossy-codec overshoot)
policy_profile() {
    case "$1" in
      archival)  echo 'TARGET_LUFS="-10.0"; TARGET_TP_DBTP="-1.0"';;
      club)      echo 'TARGET_LUFS="-8.5";  TARGET_TP_DBTP="-1.0"';;
      streaming) echo 'TARGET_LUFS="-14.0"; TARGET_TP_DBTP="-1.5"';;
      *) echo "echo 'unknown profile: $1 (use archival|club|streaming)' >&2; false";;
    esac
}

# ---- Stereo widening safety rule (LOCKED) ----
# Rule: widening is permitted ONLY if the per-frame MINIMUM phase
# correlation stays strictly above this threshold. Any negative
# minimum => widening is skipped. This is the family-wide rule
# that has consistently fired across Hardcore Pop tracks.
WIDENING_MIN_CORR_THRESHOLD="0.0"
WIDENING_EXTRASTEREO_M="1.0" # extrastereo kept at unity (inert), never removed

# ---- Bass-mono / elliptical low-end (STAGED, default OFF) ----
# When enabled (Stage D rebuild, next thread), the SIDE channel is
# high-passed below BASS_MONO_FREQ with a linear-phase filter so the
# low end collapses to mono while width above is preserved.
BASS_MONO_ENABLE="0"         # 0 = preserve current behavior (no Stage D change yet)
BASS_MONO_FREQ="110"         # Hz, family starting point (plan: ~100-120 Hz)
BASS_MONO_PHASE="linear"     # linear | minimum  (linear strongly preferred)

# ------------------------------------------------------------
# policy_decide_widening <corr_min>
#   Echoes: SKIP | ALLOW   and a human-readable reason on stderr.
#   Deterministic; pure arithmetic comparison via awk.
# ------------------------------------------------------------
policy_decide_widening() {
    local cmin="$1"
    if [ -z "$cmin" ]; then
        echo "SKIP"
        echo "  policy: no correlation min provided -> conservative SKIP" >&2
        return 0
    fi
    local verdict
    verdict=$(awk -v m="$cmin" -v t="$WIDENING_MIN_CORR_THRESHOLD" \
        'BEGIN{ print (m+0 > t+0) ? "ALLOW" : "SKIP" }')
    echo "$verdict"
    if [ "$verdict" = "SKIP" ]; then
        echo "  policy: corr_min=$cmin <= threshold=$WIDENING_MIN_CORR_THRESHOLD -> widening SKIPPED (extrastereo held at m=$WIDENING_EXTRASTEREO_M)" >&2
    else
        echo "  policy: corr_min=$cmin > threshold=$WIDENING_MIN_CORR_THRESHOLD -> widening permitted" >&2
    fi
    return 0
}

# ------------------------------------------------------------
# policy_corr_min_from_report <report.txt>
#   Extracts corr_min from the v2 diagnostic's CORR_STATS footer.
# ------------------------------------------------------------
policy_corr_min_from_report() {
    local report="$1"
    grep '^CORR_STATS' "$report" 2>/dev/null | \
        sed -n 's/.*min=\([-0-9.]*\).*/\1/p' | head -1
}
