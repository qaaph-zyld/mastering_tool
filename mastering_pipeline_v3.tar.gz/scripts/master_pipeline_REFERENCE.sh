#!/bin/bash
# ============================================================
# FFmpeg Mastering Pipeline — zeldi_bumbap_15_05
# Target: -10 LUFS integrated, -1.0 dBTP true peak
# Mastering chain: prep → EQ → comp → stereo → 4x oversampled limit
# ============================================================
set -e

SOURCE="${1:-source/zeldi_bumbap_15_05.wav}"
NAME="${2:-zeldi_bumbap_15_05}"
PROJECT_DIR="${3:-.}"

INT="${PROJECT_DIR}/intermediate"
OUT="${PROJECT_DIR}/master"
mkdir -p "$INT" "$OUT"

echo ">>> Source: $SOURCE"

# --- STAGE A: Headroom + DC + subsonic HPF ---
echo "[A] Headroom (-6dB), DC removal, HPF 25Hz/12dB"
ffmpeg -hide_banner -nostats -y -i "$SOURCE" \
    -af "volume=-6dB,dcshift=0.0004,highpass=f=25:poles=2" \
    -c:a pcm_f32le "$INT/01_prep.wav" 2>/dev/null

# --- STAGE B: Parametric EQ ---
# -1.5dB @ 200Hz Q1.2  → tame low-mid mud
# +0.8dB @ 80Hz  Q1.4  → fundamental bass
# +0.6dB @ 3.5k Q1.5   → presence
# +1.5dB @ 12k  Q0.7   → air
echo "[B] Parametric EQ"
ffmpeg -hide_banner -nostats -y -i "$INT/01_prep.wav" \
    -af "equalizer=f=200:t=q:w=1.2:g=-1.5,\
equalizer=f=80:t=q:w=1.4:g=0.8,\
equalizer=f=3500:t=q:w=1.5:g=0.6,\
equalizer=f=12000:t=q:w=0.7:g=1.5" \
    -c:a pcm_f32le "$INT/02_eq.wav" 2>/dev/null

# --- STAGE C: Bus compression (glue) ---
# threshold -16dB, ratio 1.8, attack 20ms, release 180ms, knee 4, makeup 1.5
echo "[C] Bus compression (glue)"
ffmpeg -hide_banner -nostats -y -i "$INT/02_eq.wav" \
    -af "acompressor=threshold=-16dB:ratio=1.8:attack=20:release=180:makeup=1.5:knee=4" \
    -c:a pcm_f32le "$INT/03_comp.wav" 2>/dev/null

# --- STAGE D: Stereo widening + headroom prep ---
echo "[D] Stereo widening (10%) + headroom prep (-3dB)"
ffmpeg -hide_banner -nostats -y -i "$INT/03_comp.wav" \
    -af "extrastereo=m=1.10,volume=-3dB" \
    -c:a pcm_f32le "$INT/04_stereo.wav" 2>/dev/null

# --- STAGE E: 4x oversampled true-peak limiting ---
# +6.3dB pre-gain → upsample 4x with soxr → alimiter @ 0.85 (-1.4 dBFS) → downsample 4x
echo "[E] 4x oversampled true-peak limiting (+6.3dB / 176.4kHz / -1.0 dBTP)"
ffmpeg -hide_banner -nostats -y -i "$INT/04_stereo.wav" \
    -af "volume=+6.3dB,\
aresample=176400:resampler=soxr:precision=28,\
alimiter=limit=0.85:attack=2:release=80:level=disabled,\
aresample=44100:resampler=soxr:precision=28" \
    -c:a pcm_f32le "$INT/05_limited.wav" 2>/dev/null

# --- DELIVERABLES ---
echo "[F] Deliverable 1: 32-bit float WAV (archival)"
cp "$INT/05_limited.wav" "$OUT/${NAME}_MASTER_32f.wav"

echo "[F] Deliverable 2: 16-bit WAV with TPDF dither"
ffmpeg -hide_banner -nostats -y -i "$INT/05_limited.wav" \
    -af "aresample=osf=s16:dither_method=triangular_hp" \
    -c:a pcm_s16le "$OUT/${NAME}_MASTER_16.wav" 2>/dev/null

echo "[F] Deliverable 3: 320 kbps CBR MP3 (joint stereo)"
ffmpeg -hide_banner -nostats -y -i "$INT/05_limited.wav" \
    -c:a libmp3lame -b:a 320k -joint_stereo 1 \
    "$OUT/${NAME}_MASTER.mp3" 2>/dev/null

echo ""
echo "============ FINAL LOUDNESS REPORT ============"
for f in "$OUT/${NAME}_MASTER_32f.wav" "$OUT/${NAME}_MASTER_16.wav" "$OUT/${NAME}_MASTER.mp3"; do
    echo ""
    echo "$(basename "$f")"
    ffmpeg -hide_banner -nostats -i "$f" \
        -af "ebur128=peak=true:framelog=quiet" -f null - 2>&1 | \
        grep -E "I:|LRA:|Peak:" | head -3
done

echo ""
echo "Done. Deliverables in: $OUT/"
